#include "wramp.h"

void parallel_main() {
    long switch_val = 0;
    int mask;
    int hex = 1;
    int ssdCounter;
    int divisor;
    int digit;
    long temp;
    // infinite loop
    while(1) {
        // read the value of the switches
        switch_val = WrampParallel->Switches;

        // check if button 0 is pressed
        if(WrampParallel->Buttons == 1) {
            hex = 1;
        }
        // check if button 1 is pressed
        if(WrampParallel->Buttons == 2) {
            // set hex to 0
            hex = 0;
        }
        // check if button 2 is pressed
        if(WrampParallel->Buttons == 4){
            // exit the program
            return;
        }
        // check if hex is true, which means we want to print the digits in Hex
        if(hex == 1) {
            // setting variables
            ssdCounter = 1;
            temp = switch_val;
            mask = 0xf;
            // print the appropriate digit to the appropriate SSD
            for(temp = switch_val; ssdCounter <= 4; temp >>= 4) {
                digit = temp & mask;
                if(ssdCounter == 4){
                    WrampParallel->UpperLeftSSD = digit;
                }
                else if(ssdCounter == 3){
                    WrampParallel->UpperRightSSD = digit;
                }
                else if(ssdCounter == 2){
                    WrampParallel->LowerLeftSSD = digit;
                }
                else if(ssdCounter == 1){
                    WrampParallel->LowerRightSSD = digit;
                }
                ssdCounter++;
            }
        }
        // chekc if hex is false, print the digits as decimal
        if(hex == 0) {
        // print the appropriate digit to the appropriate SSD
            temp = switch_val / 1000;
            digit = temp % 10;
            WrampParallel->UpperLeftSSD = digit;
            temp = switch_val / 100;
            digit = temp % 10;
            WrampParallel->UpperRightSSD = digit;
            temp = switch_val / 10;
            digit = temp % 10;
            WrampParallel->LowerLeftSSD = digit;
            digit = switch_val % 10;
            WrampParallel->LowerRightSSD = digit;
        }
        
    }
}
