void main()
{
	serial_main();
}
