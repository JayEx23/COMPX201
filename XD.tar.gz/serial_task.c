#include "wramp.h"

int counter = 0;
// a method that print the character c to seiral port 2
void printChar(int c) {
    // loop while TDR bit is not set
    while(!(WrampSp2->Stat & 2));

    WrampSp2->Tx = c;
}

void serial_main() {
    
    char format;
    int divisor = 100000;
    int mins;
    int sec;
    int temp;
    int format1 = 1;
    int format2 = 0;
    int format3 = 0;
    
    while(1) {
        // check if the user has inputed a character
        if(WrampSp2->Stat & 1) {
            // store the input character into c
            format = WrampSp2->Rx;
            if(format == '1') {
                format1 = 1;
                format2 = 0;
                format3 = 0;
            }
            else if (format == '2') {
                format1 = 0;
                format2 = 1;
                format3 = 0;
            }
            else if (format == '3') {
                format1 = 0;
                format2 = 0;
                format3 = 1;
            }
            else if (format == 'q') {
                return;
            }
        }
        else {
            // check if format 1 was chosen(mm:ss)
            if(format1 == 1) {
                // get the seconds of the counter
                // assuming counter increments 100 times per second
                temp = counter / 100;
                mins = (temp / 60);
                sec = temp%60;
                printChar('\r');
                printChar(((mins/10)%10) + '0');
                printChar((mins%10) + '0');
                printChar(':');
                printChar(((sec/10)%10) + '0');
                printChar((sec%10) + '0');
                printChar(' ');
                printChar(' ');

            }
            // check if format 2 was chosen(ssss.ss)
            if(format2 == 1) {
                printChar('\r');
                printChar((counter/100000) + '0');
                printChar(((counter/10000)%10) + '0');
                printChar(((counter/1000)%10) + '0');
                printChar(((counter/100)%10) + '0');
                printChar('.');
                printChar(((counter/10)%10) + '0');
                printChar((counter%10) + '0');
            }
            // check if format 3 was chosen(tttttt)
            if(format3 == 1) {
                printChar('\r');
                printChar((counter/100000) + '0');
                printChar(((counter/10000)%10) + '0');
                printChar(((counter/1000)%10) + '0');
                printChar(((counter/100)%10) + '0');
                printChar(((counter/10)%10) + '0');
                printChar((counter%10) + '0');
                printChar(' ');
            }
            

        }
    }
}