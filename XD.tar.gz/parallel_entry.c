void main()
{
	parallel_main();
}
